# Windows 10 Icon theme #

### This icon theme is made for the Windows 10 TransPack project ###

![folder](http://b00merang.weebly.com/uploads/1/6/8/1/16813022/published/9145133.png?1486514028)
